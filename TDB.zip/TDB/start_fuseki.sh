#!/bin/bash

# start the fuseki server 

# default port is 9092, can override with arg 1
port="9092"
if [ "$#" -ge 1 ]; then
    port=$1
fi

PIDFILE="/home/giot/fuseki${port}_pid"

if [ -f $PIDFILE ]
then
  PID=`cat $PIDFILE`
  if ps -p $PID > /dev/null 
  then
    echo "Server appears to be running as process $PID"
    exit 1
  fi
fi

# define some useful paths
HOME="/home/giot"
FUSEKI="$HOME/apache-jena-fuseki-2.4.0"
FUSEKI_BASE="$HOME/run"
JENA="$HOME/apache-jena-3.1.0"

# these two environment variables have to be defined
export JENA_HOME=$JENA
export FUSEKI_HOME=$FUSEKI

# start fuseki sparql server
echo "Starting GIoT Fuseki SPARQL server on port $port"
nohup $FUSEKI/fuseki-server --port=$port >fuseki${port}.log &

# write process id to file to make it easy to kill it later
echo $! > $PIDFILE

echo "Done"

