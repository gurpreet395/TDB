files for google IoT project.  All should br group writable
