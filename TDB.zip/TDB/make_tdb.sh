#!/bin/bash

# define some paths
home="/home/giot"
rdfdir="$home/data/rdf"
tdbdir="$home/data/tdb"

# make sure we're using java 8


# define JENAROOT and add it to our path
export JENAROOT=C:\TDB\apache-jena-3.1.0
PATH=$JENAROOT/bin:$PATH

# make sure that the tdb directory is there and delete any old files
rm -Rf $tdbdir > /dev/null
mkdir -p $tdbdir

# build the tdb database
tstamp=`date`
echo "Building TDB in $tdbdir from $rdfdir/*.ttl ($tstamp)\n"
$JENAROOT/bin/tdbloader2 --loc $tdbdir $rdfdir/*.ttl
tstamp=`date`
echo "Done ($tstamp)"
