#!/bin/bash

# stop the fuseki server whose pid has been saved

PIDFILE="/home/giot/fuseki9092_pid"

if [ -f $PIDFILE ]
then
  PID=`cat $PIDFILE`
else
  echo "File $PIDFILE not found!"
  exit 1
fi

if ps -p $PID > /dev/null 
then
   kill -9 $PID
   echo "Process $PID killed"
   rm $PIDFILE
else
   echo "Process $PID not running"
   rm $PIDFILE
fi


